
plugins {
    kotlin("android") version "2.0.0" apply false
    id("com.android.application") version "8.2.0" apply false
}
