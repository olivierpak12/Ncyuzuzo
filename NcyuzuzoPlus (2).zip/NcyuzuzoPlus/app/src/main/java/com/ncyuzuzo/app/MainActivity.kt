
package com.ncyuzuzo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.ncyuzuzo.app.ui.theme.NcyuzuzoPlusTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NcyuzuzoPlusTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    Greeting("Ncyuzuzo+")
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String) {
    Text(text = "Welcome to $name!")
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    NcyuzuzoPlusTheme {
        Greeting("Ncyuzuzo+")
    }
}
